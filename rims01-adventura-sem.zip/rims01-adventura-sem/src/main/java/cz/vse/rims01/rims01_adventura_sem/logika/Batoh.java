package cz.vse.rims01.rims01_adventura_sem.logika;
/**
 * Class Batoh predstvuje miesto, kde sa budu ukladat všetky veci, ktoré hráč zbiera
 *
 * @author Sabína Rimarčíková
 * @version školský rok 2020/2021
 */
import cz.vse.rims01.rims01_adventura_sem.main.PozorovatelBatoh;
import cz.vse.rims01.rims01_adventura_sem.main.PredmetPozorovaniaBatoh;

import java.util.HashSet;
import java.util.Set;

public class Batoh implements PredmetPozorovaniaBatoh {
    private static final int KAPACITA = 7;
    private static Batoh instance;

    private Set<Vec> veci;

    public Batoh(){
        this.veci = new HashSet<>();
    }

    /**
     * metoda vklada veci
     *
     */
    public boolean vloz(Vec vec){

        return this.veci.add(vec);
    }

    /**
     * metoda prechádza veci v sete a vypisuje ich názvy
     */
    public void vypisVeci() {
        for (Vec vec : veci) {
            System.out.println(vec.getNazev());
        }
    }

    public String toString(){
        return veci.toString();
    }

    /**
     * metoda vráti počet veci v sete
     */
    public int pocetVeci(){
        return this.veci.size();
    }

    /**
     * metoda prechádza veci v sete a ak sa názov veci zhoduje s vecou v sete
     * tak danu vec zo setu vymaže
     */
    public Vec vyberVec(String nazovVeci) {
        for (Vec vec : veci) {
            if (vec.getNazev().equals(nazovVeci)) {
                Vec toRet = vec;
                veci.remove(vec);
                return toRet;
            }
        }

        return null;
    }

    /**
     * metoda overuje, či sa daná vec nachádza v sete
     * @param nazovVeci názov veci o ktorej chceme vediet či sa nachadza v sete
     * @return true ak nachadza, false ak sa nenachadza
     */
    public boolean obsahujeVec(String nazovVeci) {
        for (Vec vec : veci) {
            if (vec.getNazev().equals(nazovVeci)) {
                return true;
            }
        }

        return false;
    }

    public static Batoh getInstance(){
        if (instance == null){
            instance = new Batoh();
        }
        return instance;
    }

    /**
     * zistujem či môžem vlozit do batoha
     * @return ak ano true, inak false
     */
    public boolean mohuVlozitVec (){
        if (veci.size() < KAPACITA) {
            return true;
        }
        return false;}

    @Override
    public void registrujBatoh(Vec vec) {
        veci.add(vec);
    }

    @Override
    public void odregistrujBatoh(Vec vec) {
        veci.remove(vec);

    }

    private void upozornenie(){
        for (Vec vec : veci) {
        vec.}
    }
}
