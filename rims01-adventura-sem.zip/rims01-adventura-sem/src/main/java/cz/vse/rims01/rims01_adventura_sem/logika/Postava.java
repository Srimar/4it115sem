package cz.vse.rims01.rims01_adventura_sem.logika;
/** Class Postava predstavuje postavu, ktorá sa nachádza v priestore.
 *
 * @author Sabína Rimarčíková
 * @version školský rok 2020/2021
 */
public class Postava {

    private String jmeno;
    private String chcenaVec;
    private Vec vecNaVymenu;

    public Postava(String jmeno, String chcenaVec, Vec vecNaVymenu) {
        this.jmeno = jmeno;
        this.chcenaVec = chcenaVec;
        this.vecNaVymenu = vecNaVymenu;
    }

    /**
     * metoda zistuje, či vec ktorú chce hráč vymenit, je tá ktorú postava chce
     * @param ponukanaVec vec ktorú chce hráč vymenit
     * @return názov veci ak sa rovnaju ak nie null
     */
    public Vec vymenVec(String ponukanaVec) {
        if (chcenaVec != null && chcenaVec.equals(ponukanaVec)) {
            Vec vec = vecNaVymenu;
            vecNaVymenu = null;
            return vec;
        }

        return null;
    }


    /**
     * zistuje či ma hrá vec na výmenu
     * @return ak ma vec na výmenu true, inak false
     */
    public boolean maVecNaVymenu() { return vecNaVymenu != null; }

    /**
     * metoda vracia odkaz na meno postavy
     * @return meno postavy
     */
    public String getJmeno(){
        return jmeno;
    }
}
