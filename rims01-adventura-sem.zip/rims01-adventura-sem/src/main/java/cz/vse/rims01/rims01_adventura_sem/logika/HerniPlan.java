package cz.vse.rims01.rims01_adventura_sem.logika;


import cz.vse.rims01.rims01_adventura_sem.main.Pozorovatel;
import cz.vse.rims01.rims01_adventura_sem.main.PozorovatelBatoh;
import cz.vse.rims01.rims01_adventura_sem.main.PredmetPozorovania;
import cz.vse.rims01.rims01_adventura_sem.main.PredmetPozorovaniaBatoh;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 *  Class HerniPlan - třída představující mapu a stav adventury.
 *
 *  Tato třída inicializuje prvky ze kterých se hra skládá:
 *  vytváří všechny prostory,
 *  propojuje je vzájemně pomocí východů
 *  a pamatuje si aktuální prostor, ve kterém se hráč právě nachází.
 *
 *@author     Michael Kolling, Lubos Pavlicek, Jarmila Pavlickova, Sabína Rimarčíková
 *@version    pro školní rok 2020/2021
 */
public class HerniPlan implements PredmetPozorovania, PredmetPozorovaniaBatoh {

    private Prostor aktualniProstor;
    private Batoh batoh = Batoh.getInstance();
    private Prostor finalnyProstor;
    private Set<Pozorovatel> zoznamPozorovatelov;
    public Set<PozorovatelBatoh> zoznamPozorovatelovB;


    /**
     * Konstruktor který vytváří jednotlivé prostory a propojuje je pomocí východů.
     * Jako výchozí aktuální prostor nastaví halu.
     */
    public HerniPlan(Hra hra) {
        zoznamPozorovatelov = new HashSet<>();
        zoznamPozorovatelovB = new HashSet<>();
        zalozProstoryHry();

    }

    /**
     * Vytvara jednotlive priesory a propojuje ich pomocou vychodov.
     * Taktiež  vytvara veci a postavy v priestore
     */
    private void zalozProstoryHry() {
        // Veci
        Vec odpadky = new Vec("odpadky", false);
        Vec zlato = new Vec("zlato", true);
        Vec kniha = new Vec("kniha", true);
        Vec pohar = new Vec("pohar", true);
        Vec jablko = new Vec("jablko", true);
        Vec bomba = new Vec("bomba", true, true);
        Vec kluc = new Vec("Kľúč-terasa", true);

        // Postavy
        Postava postava = new Postava("Brat", "zlato", kluc);
        Postava postava1 = new Postava("Sestra", "zlato", kniha);

        // vytvárajú se jednotlivé priestory
        Prostor predsien = new Prostor("predsien", "predsien v dome", new HashSet<>(Arrays.asList(odpadky, pohar)), null);
        Prostor kuchyna = new Prostor("kuchyna", "kuchyna v dome", new HashSet<>(Arrays.asList(jablko, pohar)), postava);
        Prostor chodba = new Prostor("chodba", "chodba v dome", new HashSet<>(Arrays.asList(bomba, odpadky)), null);
        Prostor spalna = new Prostor("spalna", "spalna v dome", new HashSet<>(Arrays.asList(zlato)), null);
        Prostor obyvacka = new Prostor("obyvacka", "obyvacka v dome", new HashSet<>(Arrays.asList(kniha, jablko)), postava1);
        Prostor terasa = new Prostor("terasa", "terasa v dome");

        // Zamknute miestnosti
        terasa.setZamknuta(true);

        // priechody (sousedne priestory)
        predsien.setVychod(kuchyna);
        predsien.setVychod(chodba);

        kuchyna.setVychod(predsien);
        kuchyna.setVychod(obyvacka);
        kuchyna.setVychod(chodba);

        chodba.setVychod(kuchyna);
        chodba.setVychod(spalna);
        chodba.setVychod(predsien);

        spalna.setVychod(chodba);

        obyvacka.setVychod(kuchyna);
        obyvacka.setVychod(terasa);

        aktualniProstor = predsien;  // hra začíná v predsieni
        finalnyProstor = terasa; //hra končí na terase
    }

    /**
     * Metoda vrací odkaz na aktuální prostor, ve ktetém se hráč právě nachází.
     *
     * @return aktuální prostor
     */

    public Prostor getAktualniProstor() {
        return aktualniProstor;
    }


    /**
     * metoda vracia odkaz na batoh
     *
     * @return batoh
     */
    public Batoh getBatoh() {
        return batoh;
    }

    /**
     * Metoda nastaví aktuální prostor, používá se nejčastěji při přechodu mezi prostory
     *
     * @param prostor nový aktuální prostor
     */
    public void setAktualniProstor(Prostor prostor) {

        aktualniProstor = prostor;
        upozorniPozorovatela();

    }


    /**
     * Metoda zistuje či aktualny a finálny priestor sa rovnaju
     *
     * @return true ak sa rovnajú, false ak sa nerovnajú
     */
    public boolean jeFinalnyProstor() {
        return aktualniProstor == finalnyProstor;
    }

    @Override
    public void registrujPozorovatela(Pozorovatel pozorovatel) {
        zoznamPozorovatelov.add(pozorovatel);
    }

    @Override
    public void odoberPozorovatela(Pozorovatel pozorovatel) {
        zoznamPozorovatelov.remove(pozorovatel);

    }

    private void upozorniPozorovatela() {
        for (Pozorovatel pozorovatel : zoznamPozorovatelov) {
            pozorovatel.update();
        }
    }
    @Override
    public void registrujBatoh(PozorovatelBatoh pozorovatelBatoh) {
        zoznamPozorovatelovB.add(pozorovatelBatoh);
    }

    @Override
    public void odregistrujBatoh(PozorovatelBatoh pozorovatelBatoh) {
        zoznamPozorovatelovB.remove(pozorovatelBatoh);

    }

    private void upozornenie(){
        for (PozorovatelBatoh pozorovatelBatoh: zoznamPozorovatelovB) {
            pozorovatelBatoh.aktualizujBatoh();
        }
    }
}