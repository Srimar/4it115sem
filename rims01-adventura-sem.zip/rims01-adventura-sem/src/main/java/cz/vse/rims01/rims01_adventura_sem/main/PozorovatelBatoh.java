package cz.vse.rims01.rims01_adventura_sem.main;

public interface PozorovatelBatoh {
    /**
     * metoda aktualizuje batoh, ked dôjde ku zmene
     */
    public void aktualizujBatoh();

}
