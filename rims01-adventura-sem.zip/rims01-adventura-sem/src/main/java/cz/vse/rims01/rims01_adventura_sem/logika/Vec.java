package cz.vse.rims01.rims01_adventura_sem.logika;

/** Class Vec predstavuje veci, ktoré sa nachádzú v priestore a hráč ich môže zbierať.
 * Nemôže zbierať všetky a pri vzatí niektorých môže dôjst ku koncu hry.
 *
 * @author Sabína Rimarčíková
 * @version školský rok 2020/2021
 */
public class Vec
{
    private String nazev;
    private boolean sebratelna;
    private boolean ukonciHru;

    /***************************************************************************
     *  Pomocou konstruktoru se vytvara instance veci.
     *  @param  nazev       název veci
     *  @param  sebratelna  či sa da vec zobrat
     */
    public Vec(String nazev, boolean sebratelna) {
        this.nazev = nazev;
        this.sebratelna = sebratelna;
        this.ukonciHru = false;
    }

    public Vec(String nazev, boolean sebratelna, boolean ukonciHru) {
        this.nazev = nazev;
        this.sebratelna = sebratelna;
        this.ukonciHru = ukonciHru;
    }

    /**
     * metoda vracia název veci
     * @return   název veci
     */
    public String getNazev() {
        return nazev;
    }

    /**
     * metoda vrátí true, pokial sa da vec z miestnosti zobrat
     * @return    true, pokud lze věc sebrat
     */
    public boolean isSebratelna() {
        return sebratelna;
    }

    /**
     * zistuje či pri vzatí nedojde ku koncu hry
     * @return ak ukonci hru true, inak false
     */
    public boolean ukonciHru() {
        return ukonciHru;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Vec) {
            Vec druha = (Vec) o;
            return nazev.equals(druha.nazev);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return nazev.hashCode();
    }

    @Override
    public String toString() {
        return nazev;
    }
}