package cz.vse.rims01.rims01_adventura_sem.logika;

/**
 *  Třída PrikazSeber implementuje pre hru príkaz zobratia.
 *  umožnuje zobrat vec z miestnoti
 *
 *@author     Sabína Rimarčíková
 *@version    pro školní rok 2020/2021
 *
 */
public class PrikazSeber implements IPrikaz {
    public static final String NAZEV = "zober";
    private HerniPlan plan;
    private Hra hra;

    public PrikazSeber(HerniPlan plan, Hra hra) {
        this.plan = plan;
        this.hra = hra;
    }

    /**
     *  Príkaz "zober". Skúša zobrať danú vec. Pokiaľ vec
     *  existuje, vezme ju. Pokiaľ zadaná vec v miestnosti nie je, vypíše sa chybové hlasenie.
     *
     *@param parametry -  parametr obsahuje jméno veci, ktorú má zobrať
     *
     *@return zpráva, kterou vypíše hra hráči
     */
    @Override
    public String provedPrikaz(String... parametry) {
        if (parametry.length == 0) {
            // pokial chyba druhé slovo (nazov predmetu), tak ....
            return "Čo mám zobrať? Musíš zadať názov predmetu";
        } else if (parametry.length>1) {
            return "Môžeš zobrat iba jednu vec!";
        }

        String predmet = parametry[0];
        Prostor aktualniProstor = plan.getAktualniProstor();

        // zkusime zobrat predmet
        if (!aktualniProstor.obsahujeVec(predmet)) {
            return "Taka vec nie je v miestnosti.";
        }

        Vec vec = aktualniProstor.odeberVec(predmet);

        if (vec == null) {
            return "Vec nie je mozne zobrat.";
        }

        if (vec.ukonciHru()) {
            hra.setKonecHry(true);
            return "Ups, tuto vec si nemal zobrat. Prehral si!";
        }

        Batoh batoh = plan.getBatoh();
        if (!batoh.mohuVlozitVec()) {
            return "Batoh je plny.";
        }

        batoh.vloz(vec);

        return "Zobral si " + vec.getNazev();
    }

    /**
     *  Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání)
     *
     *  @ return nazev prikazu
     */
    @Override
    public String getNazev() {
        return NAZEV;
    }
}
