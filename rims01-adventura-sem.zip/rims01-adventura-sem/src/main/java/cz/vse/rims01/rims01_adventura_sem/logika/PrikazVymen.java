package cz.vse.rims01.rims01_adventura_sem.logika;

/**
 *  Třída PrikazVymen implementuje pre hru príkaz výmeny.
 *  umožnuje vymeniť vec s postavou
 *
 *@author     Sabína Rimarčíková
 *@version    pro školní rok 2020/2021
 *
 */
class PrikazVymen implements IPrikaz {
    private static final String NAZEV = "vymen";
    private HerniPlan plan;

    public PrikazVymen(HerniPlan plan) {
        this.plan = plan;
    }

    /**
     *  Príkaz "vymen". Skúša vymenit danú vec.
     *@param parametry - nazov veci ktoru chce vymenit
     *
     *@return zpráva, kterou vypíše hra hráči
     */
    @Override
    public String provedPrikaz(String... parametry) {
        if (parametry.length == 0) {
            return "Aku vec chces vymenit?";
        }

        String ponukanaVec = parametry[0];

        Prostor aktualniProstor = plan.getAktualniProstor();
        Postava postava = aktualniProstor.getPostava();

        if (postava == null) {
            return "Nie je tu nikto s kym by si mohol vymenit veci.";
        }

        if (!postava.maVecNaVymenu()) {
            return "Postava nema ziadnu vec na vymenu.";
        }

        Vec ziskanaVec = postava.vymenVec(ponukanaVec);
        if (ziskanaVec == null) {
            return "Postava tvoju vec nechce. Chce inu vec.";
        }

        Batoh batoh = plan.getBatoh();
        batoh.vyberVec(ponukanaVec);
        batoh.vloz(ziskanaVec);

        return "Postava si od teba zobrala vec a ziskal si od nej novu vec - " + ziskanaVec;
    }

    /**
     *  Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání)
     *
     *  @ return nazev prikazu
     */
    @Override
    public String getNazev() {
        return NAZEV;
    }
}
