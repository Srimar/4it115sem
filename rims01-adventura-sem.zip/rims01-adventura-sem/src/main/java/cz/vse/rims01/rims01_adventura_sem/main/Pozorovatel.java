package cz.vse.rims01.rims01_adventura_sem.main;

public interface Pozorovatel {
    /**
     *metoda, ktorá vola predmet poorovaní ked dojde ku zmene
     */
    void update();
}
