package cz.vse.rims01.rims01_adventura_sem.logika;

import javax.swing.*;
import java.net.URL;

public class NapovedaHTML extends JDialog
{
    private URL souborHTML;
    private JEditorPane text;

    /**
     * Zobrazi text napovedy z HTML
     * @param soubor jmeno HTML souboru
     */
    public NapovedaHTML(String soubor){
        text = new JEditorPane();
        text.setEditable(false);
        try{
            souborHTML = this.getClass().getResource(soubor);
            text.setPage(souborHTML);
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Nejde najsť súbor nápovedy" +e,
                    "Chyba",
                    JOptionPane.INFORMATION_MESSAGE);
        }

        getContentPane().add(new JScrollPane(text));
    }

}
