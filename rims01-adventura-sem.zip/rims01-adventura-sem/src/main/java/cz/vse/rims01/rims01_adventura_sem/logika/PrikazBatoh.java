package cz.vse.rims01.rims01_adventura_sem.logika;
/**
 *  Trieda PrikazBatoh implementuje pro hru príkaz batoh.
 *
 *
 *@author     Sabína Rimarčíková
 *@version    pro školní rok 2020/2021
 */
class PrikazBatoh implements IPrikaz {

    private static final String NAZEV = "batoh";
    private Batoh batoh;

    /**
     * Konsturktor
     * @param batoh, batoh ve kterém jsou sebrané věci
     */
    public PrikazBatoh(Batoh batoh) {
        this.batoh = batoh;
    }

    @Override
    public String provedPrikaz(String... parametry) {
        return batoh.toString();
    }

    /**
     *  Metoda vracia nazov príkazu
     *
     *  @ return nazov prikazu
     */
    @Override
    public String getNazev() {
        return NAZEV;
    }
}
