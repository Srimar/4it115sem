package cz.vse.rims01.rims01_adventura_sem.main;

import cz.vse.rims01.rims01_adventura_sem.logika.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Point2D;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Graficke uzivatelske rozhranie
 *  * Rozdeli obrazovku na niekolko casti
 *  *  Menu
 *  *  vypísanie batohu, východy
 *  *
 *  * @author Sabína Rimarčíková
 *  * @version školský rok 2020/2021
 */
public class HomeController implements Pozorovatel, PozorovatelBatoh {


    @FXML private ListView batohZoznam;
    @FXML private  ImageView hrac;
    @FXML private  ListView<Prostor> zoznamVychodov;
    @FXML private Button odesli;
    @FXML private TextArea vystup;
    @FXML private TextField vstup;
    private Map<String, Point2D> souradniceProstoru = new HashMap<>();
    private Map<String, Image> obrazkyProstoru = new HashMap<>();
    private Map<String, Image> obrazkyBatohu = new HashMap<>();


    private IHra hra;

    /**
     * nastavenie hry- uvítanie, registracia Pozorovatela, vychody, obrazky
     * @param hra
     */
    public void setHra(IHra hra) {
        this.hra= hra;
        vystup.appendText(hra.vratUvitani()+ "\n\n");
        hra.getHerniPlan().registrujPozorovatela(this);


        zoznamVychodov.getItems().addAll(hra.getHerniPlan().getAktualniProstor().getVychody());

        obrazkyProstoru.put("predsien", new Image(getClass().getResourceAsStream("/hrac.png")));
        //nefunguje
        obrazkyBatohu.put("jablko", new Image(getClass().getResourceAsStream("/jablko.jpg")));
        obrazkyBatohu.put("kluc", new Image(getClass().getResourceAsStream("/kluc.jpg")));
        obrazkyBatohu.put("kniha", new Image(getClass().getResourceAsStream("/kniha.jpg")));
        obrazkyBatohu.put("odpadky", new Image(getClass().getResourceAsStream("/odpadky.jpg")));
        obrazkyBatohu.put("pohar", new Image(getClass().getResourceAsStream("/POHAR.jpg")));
        obrazkyBatohu.put("zlato", new Image(getClass().getResourceAsStream("/zlato .jpg")));


        zoznamVychodov.setCellFactory(new Callback<ListView<Prostor>, ListCell<Prostor>>() {
            @Override
            public ListCell<Prostor> call(ListView<Prostor> param) {
                return new ListCell<Prostor>() {
                    protected void updateItem(Prostor prostor, boolean empty) {
                        super.updateItem(prostor, empty);
                        if (prostor != null) {
                            setText(prostor.getNazev());
                            ImageView pohled = new ImageView(obrazkyProstoru.get(prostor.getNazev()));
                            pohled.setPreserveRatio(true);
                            pohled.setFitHeight(70);
                            setGraphic(pohled);
                        } else {
                            setText("");
                            setGraphic(new ImageView());
                        }
                    }
                };
            }
        });


/**
 * suradnice priestorov
 */
        souradniceProstoru.put("predsien", new Point2D(107,69));
        souradniceProstoru.put("kuchyna", new Point2D(48,69));
        souradniceProstoru.put("chodba", new Point2D(84,42));
        souradniceProstoru.put("spalna", new Point2D(110,29));
        souradniceProstoru.put("obyvacka", new Point2D(47,22));
        souradniceProstoru.put("terasa", new Point2D(49,-6));

    }

    /**
     * nastavenie stáleho textu (nemôžeme editovať)
     */
    public void initialize(){
        vystup.setEditable(false);

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                vstup.requestFocus();
            }
        });
    }

    /**
     * zpracovanie prikazu a potom vyčistenie vstupu
     * @param actionEvent
     */
    public void odoslanyVstup(ActionEvent actionEvent) {
        String prikaz = vstup.getText();
        zpracujPrikaz(prikaz);
        vstup.clear();
        batohZoznam.getItems().addAll(hra.getHerniPlan().getBatoh());
    }

    private void zpracujPrikaz(String prikaz) {
        String vysledok = hra.zpracujPrikaz(prikaz);

        vystup.appendText("> " + prikaz+ "\n");
        vystup.appendText(vysledok+ "\n\n");


        if (hra.konecHry()){
            vstup.setDisable(true);
            odesli.setDisable(true);
            zoznamVychodov.setDisable(true);
            vystup.appendText(hra.vratEpilog());
        }
    }


    @Override
    public void update() {
        Prostor aktualniProstor = hra.getHerniPlan().getAktualniProstor();


        //aktualne vychody
        zoznamVychodov.getItems().clear();
        zoznamVychodov.getItems().addAll(aktualniProstor.getVychody());

        Point2D souradniceAktualnihoProstoru = souradniceProstoru.get(aktualniProstor.getNazev());

        //suradnice hraca
        hrac.setLayoutX(souradniceAktualnihoProstoru.getX());
        hrac.setLayoutY(souradniceAktualnihoProstoru.getY());


    }

    /**
     * spracovanie kliknutia na východ a priradenie k príkazu
     * @param mouseEvent
     */
    public void vybranyVychod(MouseEvent mouseEvent) {
        Prostor vybranyVychod= zoznamVychodov.getSelectionModel().getSelectedItem();
        if(vybranyVychod==null) return;
        zpracujPrikaz(PrikazJdi.NAZEV +" "+ vybranyVychod);
    }

    /**
     * kliknutie v menu na napovedu
     * @param actionEvent
     */
    public void Napoveda(ActionEvent actionEvent) {
        zpracujPrikaz(PrikazNapoveda.NAZEV);
    }

    /**
     * kliknutie v menu na koniec
     * @param actionEvent
     */
    public void Koniec(ActionEvent actionEvent) {
        zpracujPrikaz(PrikazKonec.NAZEV);
    }

    /**
     * kliknutie v menu na novu hru
     * @param actionEvent
     */
    public void NovaHra(ActionEvent actionEvent) {
        hra.konecHry();
        vystup.clear();
        vstup.clear();

    }

    @Override
    public void aktualizujBatoh() {
        System.out.println("aktualiz");
    }


    //public void NovaHra(ActionEvent actionEvent) {
        //hra.getHerniPlan().jeFinalnyProstor();
       // hra.vratUvitani();
    //}

    //public void vybranaVec(MouseEvent mouseEvent) {
      //  Vec vybranaVec = zoznamVeci.getSelectionModel().getSelectedItem();
       // if(vybranaVec==null) return;
        //zpracujPrikaz(PrikazSeber.NAZEV + vybranaVec);
    //}
}
