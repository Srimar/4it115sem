package cz.vse.rims01.rims01_adventura_sem.main;

import cz.vse.rims01.rims01_adventura_sem.logika.Vec;

public interface PredmetPozorovaniaBatoh {
     void registrujBatoh(Vec vec);

    void odregistrujBatoh(Vec vec);

    }

