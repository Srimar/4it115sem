package cz.vse.rims01.rims01_adventura_sem.main;


public interface PredmetPozorovaniaBatoh {
     void registrujBatoh(PozorovatelBatoh pozorovatelBatoh);

    void odregistrujBatoh(PozorovatelBatoh pozorovatelBatoh);

    }

