package cz.vse.rims01.rims01_adventura_sem.logika;

/**
 *  Třída PrikazOdemkni implementuje pre hru príkaz odomknutia.
 *  odomyká zamknuté izby v dome
 *
 *@author     Sabína Rimarčíková
 *@version    pro školní rok 2020/2021
 *
 */
class PrikazOdemkni implements IPrikaz {
    private static final String NAZEV = "odomkni";
    private HerniPlan plan;

    /**
     *  Konstruktor triedy
     *
     *  @param plan herný plán, v ktorom sa budú odomykat prostory
     */
    public PrikazOdemkni(HerniPlan plan) {
        this.plan = plan;
    }

    /**
     *metoda zistuje podla dlžky parametrov, susedných priestorov a podla toho či nie je susedny
     * priestor zamknutý, čo môže odomknut
     * @param parametry počet parametrů závisí na konkrétním příkazu.
     * @return správa, ktorú vypíše hráčovi
     */
    @Override
    public String provedPrikaz(String... parametry) {
        if (parametry.length == 0) {
            // ak chyba druhé slovo, tak ....
            return "Čo mám odomknúť? Musíš zadat názov miestnosti";
        }

        String smer = parametry[0];

        // zadana miestnost medzi vychodmi
        Prostor sousedniProstor = plan.getAktualniProstor().vratSousedniProstor(smer);

        if (sousedniProstor == null) {
            return "Odtiaľ nevedú dvere do " + sousedniProstor + " !";
        }
        else {
            if (sousedniProstor.isZamknuta()) {
                if (plan.getBatoh().obsahujeVec(sousedniProstor.nazovKlucu())) {
                    sousedniProstor.setZamknuta(false);
                    return "Podarilo sa ti otvorit dvere do miestnosti "
                            + sousedniProstor.getNazev() + ". Teraz je cesta voľná.";
                }
                else {
                    return "Na odomknutie dverí do " + sousedniProstor + " potrebuješ mať "
                            + "pri sebe " + sousedniProstor.nazovKlucu();
                }
            }
            else {
                return "Miestnosť "+ sousedniProstor.getNazev() + " je odomknutá!";
            }
        }
    }

    /**
     *  Metoda vracia nazov príkazu (slovo které používá hráč na jeho vyvolanie)
     *
     *  @ return nazev prikazu
     */
    @Override
    public String getNazev() {
        return NAZEV;
    }
}
