package cz.vse.rims01.rims01_adventura_sem.main;

public interface PredmetPozorovania {
    /**
     * metoda pre prianie noveho pozorovatela do zoznamu pozorovatelov
     * @param pozorovatel
     */
    void registrujPozorovatela(Pozorovatel pozorovatel);

    /**
     * metoda pre odobranie pozorovatela zo zoznamu pozorovatelov
     * @param pozorovatel
     */
    void odoberPozorovatela(Pozorovatel pozorovatel);


}
