package cz.vse.rims01.rims01_adventura_sem.logika;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/*******************************************************************************
 * Testovací třída VecTest slouží ke komplexnímu otestování
 * třídy Vec
 *
 * @author    Sabína Rimarčíková
 * @version  pro školní rok 2020/2021
 */


public class VecTest {

    @BeforeEach
    public void setUp()
    {
        //fixture
    }


    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     */
    @AfterEach
    public void tearDown()
    {
        //úklid po testu
    }

    @Test
    public void TestJeZberaelna(){
        Vec vec1 = new Vec("zlato",true);
        Vec vec2 = new Vec("odpadky",false);
        assertEquals(true,vec1.isSebratelna());
        assertEquals(false,vec2.isSebratelna());

    }

    @Test
    public void TestUkonciHru(){
        Vec vec1 = new Vec("zlato",true,false);
        Vec vec2 = new Vec("bomba",true,true);
        assertEquals(false,vec1.ukonciHru());
        assertEquals(true,vec2.ukonciHru());

    }
}
