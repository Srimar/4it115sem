package cz.vse.rims01.rims01_adventura_sem.logika;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BatohTest {
    private Vec vec1;
    private Vec vec2;
    private Vec vec3;
    private Vec vec4;
    private Batoh batoh1;

    public BatohTest() {
    }

    @BeforeEach
    public void setUp() {
        this.vec1 = new Vec("zlato", true);
        this.vec2 = new Vec("kniha", true);
        this.vec3 = new Vec("papier", true);
        this.vec4 = new Vec("pohar", true);
        this.batoh1 = new Batoh();
    }
    @AfterEach
    public void tearDown()
    {
    }

    @Test
    public void TestVlozdoBatohu(){
        assertEquals(true, batoh1.vloz(vec1));
        assertEquals(true,batoh1.obsahujeVec("zlato"));
        assertEquals(true, batoh1.vloz(vec2));
        assertEquals(true,batoh1.obsahujeVec("kniha"));
        assertEquals(true, batoh1.vloz(vec3));
        assertEquals(true,batoh1.obsahujeVec("papier"));
    }

    @Test
    public void testVyberVec()
    {
        assertEquals(true, batoh1.vloz(vec1));
        assertEquals(true, batoh1.obsahujeVec("zlato"));
        assertEquals(false, batoh1.obsahujeVec("kniha"));

    }
}
