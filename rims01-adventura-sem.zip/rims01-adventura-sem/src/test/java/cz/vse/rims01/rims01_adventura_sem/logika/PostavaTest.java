package cz.vse.rims01.rims01_adventura_sem.logika;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/*******************************************************************************
 * Testovací třída PostavaTest slouží ke komplexnímu otestování
 * třídy Postava
 *
 * @author    Sabína Rimarčíková
 * @version  pro školní rok 2020/2021
 */


public class PostavaTest {
    private Vec vec1;
    private Vec vec2;
    private Vec vec3;
    private Vec vec4;

    @BeforeEach
    public void setUp()
    {
        this.vec1 = new Vec("peniaze",true);
    }


    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     */
    @AfterEach
    public void tearDown()
    {
    }

    @Test
    public void TestGetJmeno() {
        Postava postava1 = new Postava("Adam","kniha",vec1);
        assertEquals("Adam", postava1.getJmeno());
        Postava postava2 = new Postava("Petra","kniha",vec1);
        assertEquals("Petra", postava2.getJmeno());
    }

    @Test
    public void TestVymenVec(){
        Postava postava1 = new Postava("Adam","kniha",vec1);
        assertEquals(true, postava1.maVecNaVymenu());
        Postava postava2 = new Postava("Simona","zlato",null);
        assertEquals(false, postava2.maVecNaVymenu());


    }
}
